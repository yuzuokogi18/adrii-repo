const movies = [
    {
        title: "El Ladrón del Rayo",
        director: " Rick Riordan ",
        year:2005,
        image: "OIP.jpeg"
    },
    {
        title: "Interstellar",
        director: "Rick Riordan",
        year:2006,
        image: "libro2.jpg"
    },
    {
        title: "The Dark Knight",
        director: "Rick Riordan",
        year: 2008,
        image: "libro3.jpg"
    },
    {
        title: "Pulp Fiction",
        director: "Rick Riordan",
        year: 2012,
        image: "libro4.jpg"
    },
    {
        title: "The Matrix",
        director: "Rick Riordan",
        year: 2014,
        image: "libto5.jpeg"
    }
];

export default movies;
