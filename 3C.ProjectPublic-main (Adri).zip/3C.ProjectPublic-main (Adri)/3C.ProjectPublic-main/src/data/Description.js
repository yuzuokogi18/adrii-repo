export const descriptionData = {
    text: "Personajes principales: Percy Jackson, Annabeth Chase, Grover Underwood Personajes secundarios: Nico di Angelo, Luke Castellan, Sally Jackson, Thalia Grace.Trama: Cuenta las aventuras de un chico actual de doce años, Percy Jackson, cuando descubre que es un semidiós; hijo de una mortal y del dios griego, Poseidón. Percy y sus amigos realizan una búsqueda para prevenir una guerra apocalíptica entre los dioses griegos Zeus y Poseidón.",
    image: "Libros.jpg"
  };
  