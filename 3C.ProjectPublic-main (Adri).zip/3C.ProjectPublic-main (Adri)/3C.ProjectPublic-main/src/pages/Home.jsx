
import Section from "../components/organisms/Section";

function Home() {
    return (<Section></Section>  );
}

export default Home;