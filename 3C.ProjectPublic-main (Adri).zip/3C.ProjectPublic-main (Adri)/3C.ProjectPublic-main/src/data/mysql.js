const mysql = {
    products : [
        {
            image: 'xd.jpeg',
            
        }
    ]
}

export default mysql;