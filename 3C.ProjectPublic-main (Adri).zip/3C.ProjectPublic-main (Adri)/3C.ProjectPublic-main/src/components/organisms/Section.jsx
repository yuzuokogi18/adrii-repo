import Grid from "../molecules/Grid";
import Title from "../molecules/Title";
import Cart from "../molecules/Cart";
import Description from "../molecules/Description";







function Section() {
    return (
    <>
        <Grid></Grid>  
        <Title></Title>
        <Cart></Cart>
        <Description></Description>
    
    </>)
}

export default Section;